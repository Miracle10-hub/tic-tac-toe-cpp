# 🎮 Tic-Tac-Toe in C++

This is a small C++ project I made to practice arrays, functions, and basic game logic.
